self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e15604df2bf377c55d3728b7c3be752d",
    "url": "/redirect/build/statement/index.html"
  },
  {
    "revision": "3a589b6659fa6e4ae3c3",
    "url": "/redirect/build/statement/static/css/main.5f361e03.chunk.css"
  },
  {
    "revision": "67d7f8a24600a1906d9b",
    "url": "/redirect/build/statement/static/js/2.ed9f69ca.chunk.js"
  },
  {
    "revision": "9eb0a5bd0be8ca3e507f266cf1e736cc",
    "url": "/redirect/build/statement/static/js/2.ed9f69ca.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3a589b6659fa6e4ae3c3",
    "url": "/redirect/build/statement/static/js/main.2f62b36d.chunk.js"
  },
  {
    "revision": "616337ac568d0973ba6c",
    "url": "/redirect/build/statement/static/js/runtime-main.f5750268.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/redirect/build/statement/static/media/logo.5d5d9eef.svg"
  }
]);