self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8d7f87072a6fc5448e293f3b5cbcdd2d",
    "url": "/redirect/build/index.html"
  },
  {
    "revision": "d9310b9445e7f559dd64",
    "url": "/redirect/build/static/css/main.5f361e03.chunk.css"
  },
  {
    "revision": "76896039e2c8890520ce",
    "url": "/redirect/build/static/js/2.3359938d.chunk.js"
  },
  {
    "revision": "9eb0a5bd0be8ca3e507f266cf1e736cc",
    "url": "/redirect/build/static/js/2.3359938d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d9310b9445e7f559dd64",
    "url": "/redirect/build/static/js/main.300820a7.chunk.js"
  },
  {
    "revision": "d455f0cd97e21aeaef23",
    "url": "/redirect/build/static/js/runtime-main.6b786a7d.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/redirect/build/static/media/logo.5d5d9eef.svg"
  }
]);